## Deterministic masternode migration wizard ##

The documentation of the migration process to deterministic masternodes 
is not ready yet. 

The following document describes the most important aspects on this topic:
https://docs.dash.org/en/latest/masternodes/dip3-upgrade.html#masternode-registration-from-dmt