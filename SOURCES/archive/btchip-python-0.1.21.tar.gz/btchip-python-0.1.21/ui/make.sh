#!/bin/bash
pyuic4 personalization-00-start.ui -o ../btchip/ui/personalization00start.py
pyuic4 personalization-01-seed.ui -o ../btchip/ui/personalization01seed.py
pyuic4 personalization-02-security.ui -o ../btchip/ui/personalization02security.py
pyuic4 personalization-03-config.ui -o ../btchip/ui/personalization03config.py
pyuic4 personalization-04-finalize.ui -o ../btchip/ui/personalization04finalize.py
pyuic4 personalization-seedbackup-01.ui -o ../btchip/ui/personalizationseedbackup01.py
pyuic4 personalization-seedbackup-02.ui -o ../btchip/ui/personalizationseedbackup02.py
pyuic4 personalization-seedbackup-03.ui -o ../btchip/ui/personalizationseedbackup03.py
pyuic4 personalization-seedbackup-04.ui -o ../btchip/ui/personalizationseedbackup04.py


