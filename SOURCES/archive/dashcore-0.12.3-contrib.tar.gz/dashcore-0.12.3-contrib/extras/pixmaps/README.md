These replace the pixmaps in the dashcore-source/share/pixmaps/ directory.
