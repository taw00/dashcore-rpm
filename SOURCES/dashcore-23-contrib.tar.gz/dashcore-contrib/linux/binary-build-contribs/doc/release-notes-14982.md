New RPCs
--------

- The RPC `getrpcinfo` returns runtime details of the RPC server. At the moment
  it returns the active commands and the corresponding execution time.
