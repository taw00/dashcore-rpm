Miscellaneous RPC changes
------------

- The `unloadwallet` RPC is now synchronous, meaning that it blocks until the
  wallet is fully unloaded.
