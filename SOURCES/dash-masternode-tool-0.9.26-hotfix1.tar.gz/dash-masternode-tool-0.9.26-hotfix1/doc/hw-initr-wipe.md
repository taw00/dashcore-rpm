
# Hardware wallet wiping
This is a simple two-step procedure that can be performed if it is necessary to clear the hardware wallet memory for some reason.

### Procedure steps

1. Select the type of hardware wallet in use in the first step of the wizard
2. Select the `Wipe hardware wallet` option
3. Confirm that you really want to wipe the device in the dialog
4. Confirm one final time using the physical button on the hardware wallet

